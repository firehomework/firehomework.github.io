package com.hivetest.main;


import java.io.IOException;
import java.sql.*;
import java.util.Iterator;
import java.util.TreeMap;

public class testApplication {
    //hive2
    public static final String driverName = "org.apache.hive.jdbc.HiveDriver";
    public static final String HOST = "192.168.186.132:10000";
    public static final String DATABASE = "flight";
    public static final String URL = "jdbc:hive2://" + HOST + "/" + DATABASE;
    //配置mysql,注意自己改一下runoob那里
    public static final String MySQLName = "com.mysql.cj.jdbc.Driver";
    public static final String MySQLURL = "jdbc:mysql://localhost:3306/hive?useSSL=false&serverTimezone=GMT%2B8&useUnicode=true&characterEncoding=UTF-8";

    public static void main(String[] args) throws SQLException, ClassNotFoundException, IOException {

        //使用hiveserver2进行配置
        Class.forName(driverName);
        //添加MySql驱动
        Class.forName(MySQLName);
        //账号密码，配置在hive里
        Connection conn = DriverManager.getConnection(URL, "hive", "123456");
        Statement stmt = conn.createStatement();
        //获取MySQL的connection
        Connection mysqlconn = DriverManager.getConnection(MySQLURL, "root", "password");
        //忘了还有个preparedStatement,真郁闷！
        //两个用来保存数据的TreeMap。
        TreeMap<Integer, Integer> weekana = new TreeMap<Integer, Integer>();
        TreeMap<String, Integer> flightnumana = new TreeMap<>();
        //获取星期数据（直接使用之前测试的内容）
        String hql = "select DayOfWeek, count(*) from FlightInfo1987 group by DayOfWeek";
        //使用结果集保存数据（和MySql基本一致）
        ResultSet resultSet = stmt.executeQuery(hql);
        while (resultSet.next()) {
            //处理获取第一行是不是DayOfWeek(如果是，返回的null?好奇怪，有人能解释一下为什么吗)
            String week = resultSet.getString(1);
            if (week != null)
                //输入到weekana的表内
                weekana.put(Integer.parseInt(week), resultSet.getInt(2));
            System.out.println(week + "\t" + resultSet.getInt(2));
        }
        //group by分组并用sum函数对一组中的distance变量下的数据进行求和
        hql = "select uniquecarrier, flightnum, sum(distance) from FlightInfo1987 group by uniquecarrier,flightnum";
        resultSet = stmt.executeQuery(hql);
        while (resultSet.next()) {
            //使用distance进行判断。同样的问题，这个null是什么情况……？
            if (resultSet.getString(3) != null)
                //添加到flightnumana内
                flightnumana.put(resultSet.getString(1) + resultSet.getString(2), Integer.parseInt(resultSet.getString(3)));
            System.out.println(resultSet.getString(1) + resultSet.getString(2) + "\t" + resultSet.getString(3));
        }
        resultSet.close();
        stmt.close();
        conn.close();
        //hive流程完毕，开始mysql流程（下面的都没有考虑多次插入，到时候手动清理一遍表得了，懒得多写了，烦死了）
        String my_sql = "INSERT INTO `weektable` (`week`, `number`) VALUES (?, ?)";
        PreparedStatement pstmt = mysqlconn.prepareStatement(my_sql);
        //遍历整个week表获取key-value。
        Integer key = null;
        Integer integ = null;
        for (Integer integer : weekana.keySet()) {
            // 获取key
            key = integer;
            // 根据key，获取value
            integ = (Integer) weekana.get(key);
            //输入到pstmt,并添加最后的验证输入（防止插入两遍，测试用的）
            pstmt.setInt(1, key);
            pstmt.setInt(2, integ);
            //提交请求并commit(自动commit开着，很奇怪，这是啥的设定？不用写xxx.commit()了？
            int result = pstmt.executeUpdate();
        }
        //提交请求并commit(自动commit开着，很奇怪，这是啥的设定？不用写xxx.commit()了？

        //插入第二个表
        String my_sql2 = "INSERT INTO `flighttable` (`flightname`, `distance`) VALUES (?, ?)";
        pstmt = mysqlconn.prepareStatement(my_sql2);
        //遍历整个flight表获取key-value。
        String key2 = null;
        Integer integ2 = null;
        for (String s : flightnumana.keySet()) {
            // 获取key
            key2 = s;
            // 根据key，获取value
            integ2 = (Integer) flightnumana.get(key2);
            //插入第二个表
            pstmt.setString(1, key2);
            pstmt.setInt(2, integ2);
            //提交请求并commit(自动commit开着，很奇怪，这是啥的设定？不用写xxx.commit()了？
            int result2 = pstmt.executeUpdate();
        }
        stmt.close();
        pstmt.close();
        conn.close();
        //web服务放到最后
        new SimpleHTTPServer(8080);
    }
}
