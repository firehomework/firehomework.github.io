package com.hivetest.main;

import fi.iki.elonen.NanoHTTPD;

import java.io.IOException;
import java.sql.*;

import static com.hivetest.main.testApplication.MySQLName;
import static com.hivetest.main.testApplication.MySQLURL;

//用于完成Web部分
public class SimpleHTTPServer extends NanoHTTPD {

    public SimpleHTTPServer(int port) throws IOException {
        //设置端口为8080
        super(8080);
        //在这个类被新建的时候，立即启动HTTPD Server
        start(NanoHTTPD.SOCKET_READ_TIMEOUT, false);
    }
    @Override
    public Response serve(IHTTPSession session) {

        //表格前半部分
        String headstr = "<!DOCTYPE html>\n" +
                "<html>\n" +
                "<head>\n" +
                "<meta charset=\"utf-8\">\n" +
                "<title>结果报告</title>\n" +
                "</head>\n" +
                "<body>\n" +
                "\t<h1>航班统计</h1>\n" +
                "  <table border=\"1\">\n" +
                "    <tr>\n" +
                "      <td>WEEK</td>\n" +
                "      <td>NUM</td>\n" +
                "      </tr>";

        String sql = "SELECT " +
                "weektable.`week`, " +
                "weektable.number " +
                "FROM " +
                "weektable";
        String sql2 = "SELECT " +
                "flighttable.flightname," +
                "flighttable.distance " +
                "FROM " +
                "flighttable";
        //表格中段，需要自己添加从SQL里取到的数据，这个程序写的很乱，应该把DB单独拿出来的，不过现在说也没啥意思了。
        StringBuilder sheet = new StringBuilder();
        StringBuilder sheet2 = new StringBuilder();
        try {

                    Class.forName(MySQLName);
            Connection sqlcon = DriverManager.getConnection(MySQLURL, "root", "password");
            PreparedStatement pstmt = sqlcon.prepareStatement(sql);
            PreparedStatement pstmt2 = sqlcon.prepareStatement(sql2);
            ResultSet rs = pstmt.executeQuery();
            ResultSet rs2 = pstmt2.executeQuery();
            while (rs.next()) {
                sheet.append("<tr>").append("<td>").append(rs.getInt(1)).append("</td>").append("<td>").append(rs.getInt(2)).append("</td>").append("</tr>");
            }

            rs.close();
            pstmt.close();
            while (rs2.next()) {
                sheet2.append("<tr>").append("<td>").append(rs2.getString(1)).append("</td>").append("<td>").append(rs2.getInt(2)).append("</td>").append("</tr>");
            }
            pstmt2.close();
            rs2.close();
            sqlcon.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        String weeksheet = sheet.toString();
        String flightsheet = sheet2.toString();
                String centerstr = "</tr>" +
                " </table>\n" +
                "  <h1>航班统计2</h1>\n" +
                "    <table border=\"1\">\n" +
                "    <tr>\n" +
                "      <td>FLIGHTNUM</td>\n" +
                "      <td>DISTANCE</td>\n" +
                "      </tr>\n" +
                "    <tr>";
        String laststr = "</tr>\n" +
                "    </table>\n" +
                "\n" +
                "</body>\n" +
                "</html>";
        String allstr = headstr + weeksheet + centerstr + flightsheet + laststr;
        return newFixedLengthResponse(allstr);
    }
}
